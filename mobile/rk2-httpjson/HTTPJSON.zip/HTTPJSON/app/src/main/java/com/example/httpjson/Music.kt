package com.example.httpjson

class Music (val type: String, val url: String, val genre: String, val id: Int ) {
}